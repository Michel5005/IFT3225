import { useEffect, useState } from 'react'

function Product({ id, name, price, category_id, onReadClick, onEditClick, onDeleteClick }){
  return (
    <>
      <td>{name}</td> 
      <td>{price}</td> 
      <td>{category_id}</td> 
      <td>
        <button className='btn btn-primary m-r-10px read-one-product-button' data-id={id} onClick={onReadClick}><span className='glyphicon glyphicon-eye-open'></span> Read</button> 
        <span> </span>
        <button className='btn btn-info m-r-10px update-product-button' data-id={id} onClick={onEditClick}><span className='glyphicon glyphicon-edit' onClick={onEditClick}></span> Edit</button>
        <span> </span>
        <button className='btn btn-danger delete-product-button' data-id={id} onClick={onDeleteClick}><span className='glyphicon glyphicon-remove'></span> Delete</button>
      </td> 
    </>
  )
} 

function App() {
  const [produits, setProduits] = useState(null);
  const [read, setRead] = useState(null);
  const [edit, setEdit] = useState(null);
  const [del, setDel] = useState(null);
  const [update, setUpdate] = useState(null);
  const [create, setCreate] = useState(false);
  const [addProduct, setAddProduct] = useState(false);
  const [search, setSearch] = useState(null);
  const [searchProduct, setSearchProduct] = useState(false);

  useEffect(() => {
    if(read){
      fetch('http://localhost:3000/product/' + read, { method: 'GET' })
        .then(rep => rep.json())
        .then( rep => {
          setProduits(rep);
        })
        .catch(err => console.log(err));
    }else if(del){
      fetch('http://localhost:3000/product/' + del, { method: 'DELETE' })
        .then(rep => rep.json())
        .then( rep => {
          setDel(null);
        })
        .catch(err => console.log(err));
    }else if(edit){
      fetch('http://localhost:3000/product/' + edit, { method: 'GET' })
        .then(rep => rep.json())
        .then( rep => {
          setProduits(rep);
        })
        .catch(err => console.log(err));
    }else if(update){
      fetch('http://localhost:3000/product/' + update, 
      {
        method: 'PUT',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(
          {
            "name": produits.name,
            "description": produits.description,
            "category_id": produits.category_id,
            "price": produits.price
          }
        ) 
      })
        .then(() => setUpdate(null));
    }else if(addProduct){
      fetch('http://localhost:3000/product/', 
      {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(
          {
            "name": produits.name,
            "description": produits.description,
            "category_id": produits.category_id,
            "price": produits.price
          }
        ) 
      })
        .then(() => setAddProduct(false));
    }else if(search){
      console.log(search);
      fetch('http://localhost:3000/product/s/' + search, { method: 'GET' })
        .then(rep => rep.json())
        .then( rep => {
          const liste = rep.slice();
          setProduits(liste);
          //setSearchProduct(false);
          setSearch(null);
        })
        .catch(err => console.log(err));  
    }else{
      fetch('http://localhost:3000/product', { method: 'GET' })
        .then(rep => rep.json())
        .then( rep => {
          const liste = rep.slice();
          setProduits(liste);
        })
        .catch(err => console.log(err));
    }
  }, [read, edit, del, update, addProduct, searchProduct]);

  function handleReadClick(i){
    setRead(i);
  }

  function handleEditClick(i){
    setEdit(i);
  }

  function handleDeleteClick(i){
    if(confirm("Are you sure?"))
      setDel(i);
  }

  function handleProducts(){
    if(read)
      setRead(null);
    else if(edit)
      setEdit(null);
    else if(create)
      setCreate(false);
  }

  function handleCreate(){
    setCreate(true);
  }

  function handleSubmit(){
    if(edit){
      setUpdate(edit);
      setEdit(null);
    }else{
      setCreate(false);
      setAddProduct(true);
    }
  }

  function handleSearch(){
    if(search){
      console.log("Ici : " + search);
      setSearchProduct(true);
    }else{
      console.log("La : " + search);
      //setSearch(null);
      setSearchProduct(false);
    }
  }

  if(read){
    return(
      <>
        <div className='container'>
          <div className='page-header'>
            <h1 id='page-title'>Product Details </h1>
            <div id='page-content'>
              <div id='read-products' className='btn btn-primary pull-right m-b-15px read-products-button' onClick={handleProducts}>
                <span className='glyphicon glyphicon-list'></span> Read Products
              </div>
              <table className='table table-bordered table-hover'>
                <tbody>
                    <tr>
                      <td>Name</td><td>{produits.name}</td>
                    </tr>
                    <tr>
                      <td>Price</td><td>{produits.price}</td>
                    </tr>
                    <tr>
                      <td>Description</td><td>{produits.description}</td>
                    </tr>
                    <tr>
                      <td>Category</td><td>{produits.category_id}</td>
                    </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </>
    )
  } else if(edit || create){
    return(
      <>
        <div className='container'>
          <div className='page-header'>
            <h1 id='page-title'>{edit ? "Edit Product" : "Create Product"}</h1>
            <div id='page-content'>
              <div id='read-products' className='btn btn-primary pull-right m-b-15px read-products-button' onClick={handleProducts}>
                <span className='glyphicon glyphicon-list'></span> Read Products
              </div>
              <form method='post' action='#'>   
                <table className='table table-bordered table-hover'>
                  <tbody>
                    <tr>
                      <td>Name</td>
                      <td><input 
                            type='text' 
                            value={search || ""} 
                            onChange={(e) => {
                              setProduits(previousState => {
                                return {...previousState, name: e.target.value}
                              } );
                            }}
                      /></td>                                                                  
                    </tr>
                    <tr>
                      <td>Price</td>
                      <td><input 
                            type='number' 
                            value={produits.price || ""} 
                            onChange={(e) => {
                              setProduits(previousState => {
                                return {...previousState, price: e.target.value}
                              } );
                            }}
                          />
                      </td>
                    </tr>
                    <tr>
                      <td>Description</td>
                      <td><input 
                            type='text' 
                            value={produits.description || ""} 
                            onChange={(e) => {
                              setProduits(previousState => {
                                return {...previousState, description: e.target.value}
                              } );
                            }}
                          />
                      </td>
                    </tr>
                    <tr>
                      <td>Category</td>
                      <td><input 
                            type='number' 
                            value={produits.category_id || ""} 
                            onChange={(e) => {
                              setProduits(previousState => {
                                return {...previousState, category_id: e.target.value}
                              } );
                            }}
                          />
                      </td>
                    </tr>
                    <tr>
                      <td></td><td>
                        <button type='submit' className='btn btn-info' onClick={handleSubmit}>
                          <span className='glyphicon glyphicon-edit'></span>
                          { edit ? "Update Product" : "Create Product" }
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </form>
            </div>
          </div>
        </div>
      </>
    )
  }else if(Array.isArray(produits) && !read && !edit && !del){
    return (
      <>
        <div className='container'>
          <div className='page-header'>
            <h1 id='page-title'>Read Products</h1>
            <div id='page-content'>
              <form id='search-product-form' action='#' method='get'>
                <div className='input-group pull-left w-30-pct'>
                <input 
                  type='text' 
                  value={search || ""} 
                  name='keywords' 
                  className='form-control product-search-keywords' 
                  placeholder='Search products...' 
                  onChange={(e) => {
                    setSearch(e.target.value)}
                  }   
                />
                  <span className='input-group-btn'>
                    <button type='submit' className='btn btn-default' onClick={handleSearch}>
                      <span className='glyphicon glyphicon-search'></span>
                      Search
                    </button>
                  </span>
                </div>
              </form>
              <button id='create-product' className='btn btn-primary pull-right m-b-15px create-product-button' onClick={handleCreate}>
                <span className='glyphicon glyphicon-plus'></span> Create Product
              </button>
              <table className='table table-bordered table-hover'>
                <thead>
                  <tr>
                    <th className='w-25-pct'>Name</th>
                    <th className='w-10-pct'>Price</th>
                    <th className='w-15-pct'>Category</th>
                    <th className='w-25-pct text-align-center'>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {produits.map((produit, index) => (
                    <tr key={index}>
                      <Product 
                        id={produit._id} 
                        name={produit.name} 
                        price={produit.price} 
                        category_id={produit.category_id} 
                        onReadClick={() => handleReadClick(produit._id)} 
                        onEditClick={() => handleEditClick(produit._id)} 
                        onDeleteClick={() => handleDeleteClick(produit._id)}
                      />
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </>
    )
  }
}

export default App
